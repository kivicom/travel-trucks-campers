import { createSlice } from '@reduxjs/toolkit';
import { fetchCampers, fetchCamperDetails } from './campersOps';

const initialState = {
  items: [],
  camperDetails: null, // Поле для деталей кемпера
  isLoading: false,
  error: null,
};

const campersSlice = createSlice({
  name: 'campers',
  initialState,
  reducers: {},
  extraReducers: builder => {
    builder
      .addCase(fetchCampers.pending, state => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchCampers.fulfilled, (state, action) => {
        state.isLoading = false;
        state.items = action.payload.items;
      })
      .addCase(fetchCampers.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Запити для деталей кемпера
      .addCase(fetchCamperDetails.pending, state => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchCamperDetails.fulfilled, (state, action) => {
        state.isLoading = false;
        state.camperDetails = action.payload;
      })
      .addCase(fetchCamperDetails.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  },
});

// Селектори
export const selectCampers = state => state.campers.items;
export const selectCamperDetails = state => state.campers.camperDetails; // Селектор для деталей кемпера
export const selectIsLoading = state => state.campers.isLoading;
export const selectError = state => state.campers.error;

export default campersSlice.reducer;

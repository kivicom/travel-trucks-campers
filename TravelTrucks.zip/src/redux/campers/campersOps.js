import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Базовий URL для API
axios.defaults.baseURL = 'https://66b1f8e71ca8ad33d4f5f63e.mockapi.io';

// Запит для отримання всіх кемперів
export const fetchCampers = createAsyncThunk(
  'campers/fetchAll',
  async (_, thunkAPI) => {
    try {
      const response = await axios.get('/campers');
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Запит для отримання деталей кемпера за ID
export const fetchCamperDetails = createAsyncThunk(
  'campers/fetchDetails',
  async (id, thunkAPI) => {
    try {
      const response = await axios.get(`/campers/${id}`);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

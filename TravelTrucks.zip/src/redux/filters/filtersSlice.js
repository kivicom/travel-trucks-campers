import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  location: '',
  bodyType: '',
  features: {},
};

const filtersSlice = createSlice({
  name: 'filters',
  initialState,
  reducers: {
    setLocation(state, action) {
      state.location = action.payload;
    },
    setBodyType(state, action) {
      state.bodyType = action.payload;
    },
    toggleFeature(state, action) {
      const feature = action.payload;
      state.features[feature] = !state.features[feature];
    },
    resetFilters() {
      return initialState;
    },
  },
});

export const { setLocation, setBodyType, toggleFeature, resetFilters } =
  filtersSlice.actions;

export const selectFilters = state => state.filters;

export default filtersSlice.reducer;

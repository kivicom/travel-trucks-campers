import { lazy, Suspense } from 'react';
import './assets/styles/styles.css';
import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout/Layout';

import NotFoundPage from './pages/NotFoundPage/NotFoundPage';
import Loader from './components/Loader/Loader';
import ReviewsList from './components/ReviewsList/ReviewsList';
import Features from './components/Features/Features';
const HomePage = lazy(() => import('./pages/HomePage/HomePage'));
const CatalogPage = lazy(() => import('./pages/CatalogPage/CatalogPage'));
const CamperDetailsPage = lazy(() =>
  import('./pages/CamperDetailsPage/CamperDetailsPage')
);

function App() {
  return (
    <>
      <Suspense fallback={<Loader />}>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="catalog" element={<CatalogPage />} />
            <Route path="catalog/:id" element={<CamperDetailsPage />}>
              <Route path="features" element={<Features />} />
              <Route path="reviews" element={<ReviewsList />} />
            </Route>
          </Route>
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Suspense>
    </>
  );
}

export default App;

import { useDispatch, useSelector } from 'react-redux';
import { NavLink, Outlet, useParams } from 'react-router-dom';
import { fetchCamperDetails } from '../../redux/campers/campersOps';
import { selectCamperDetails } from '../../redux/campers/campersSlice';
import { Suspense, useEffect } from 'react';
import Loader from '../../components/Loader/Loader';
import styles from './CamperDetailsPage.module.css';
import Container from '../../components/Container/Container';

const CamperDetailsPage = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const camperDetails = useSelector(selectCamperDetails);

  useEffect(() => {
    dispatch(fetchCamperDetails(id));
  }, [dispatch, id]);

  if (!camperDetails) {
    return <Loader />;
  }
  const getActiveClass = ({ isActive }) => {
    return isActive ? styles.active : '';
  };

  return (
    <div>
      <Container>
        <h1>{camperDetails.name}</h1>
        <p>{camperDetails.description}</p>
        <ul>
          <li>
            <NavLink className={getActiveClass} to="features">
              Features
            </NavLink>
          </li>
          <li>
            <NavLink className={getActiveClass} to="reviews">
              Reviews
            </NavLink>
          </li>
        </ul>
        <Suspense fallback={<Loader />}>
          <Outlet />
        </Suspense>
      </Container>
    </div>
  );
};

export default CamperDetailsPage;

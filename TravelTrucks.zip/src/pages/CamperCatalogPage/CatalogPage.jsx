import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  selectCampers,
  selectIsLoading,
} from '../../redux/campers/campersSlice';
import { fetchCampers } from '../../redux/campers/campersOps';
import CampersList from '../../components/CamperCatalog/CampersList/CampersList';
import Filters from '../../components/CamperCatalog/Filters/Filters';
import styles from './CatalogPage.module.css';
import FilterBar from '../../components/CamperCatalog/FilterBar/FilterBar';

const CatalogPage = () => {
  const [search, setSearch] = useState('');
  const dispatch = useDispatch();
  const campers = useSelector(selectCampers);
  const isLoading = useSelector(selectIsLoading);

  useEffect(() => {
    dispatch(fetchCampers());
  }, [dispatch]);

  const handleSearchChange = value => {
    setSearch(value);
  };
  return (
    <div className={styles.catalogContainer}>
      <aside className={styles.filters}>
        <Filters />
      </aside>
      <section className={styles.campersList}>
        <FilterBar searchValue={search} onSearchChange={handleSearchChange} />
        {isLoading ? <p>Loading...</p> : <CampersList campers={campers} />}
      </section>
    </div>
  );
};

export default CatalogPage;

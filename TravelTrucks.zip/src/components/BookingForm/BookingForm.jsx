import styles from './BookingForm.module.css';

const BookingForm = () => {
  const handleSubmit = event => {
    event.preventDefault();
    alert('Booking request sent!');
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit}>
      <h2>Book your campervan now</h2>
      <p>Stay connected! We are always ready to help you.</p>
      <label>
        Name
        <input type="text" name="name" required />
      </label>
      <label>
        Email
        <input type="email" name="email" required />
      </label>
      <label>
        Booking date
        <input type="date" name="date" required />
      </label>
      <label>
        Comment
        <textarea name="comment" rows="4"></textarea>
      </label>
      <button type="submit" className={styles.button}>
        Send
      </button>
    </form>
  );
};

export default BookingForm;

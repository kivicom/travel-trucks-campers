const Features = ({ features = {} }) => {
  if (!features || typeof features !== 'object') {
    return <p>No features available.</p>;
  }

  const trueFeatures = Object.entries(features)
    .filter(([value]) => value === true)
    .map(([key]) => key);

  const textFeatures = Object.entries(features)
    .filter(([value]) => typeof value === 'string')
    .map(([key, value]) => `${key}: ${value}`);

  return (
    <div>
      <h3>Features</h3>
      <ul>
        {trueFeatures.map(feature => (
          <li key={feature}>{feature}</li>
        ))}

        {textFeatures.map(feature => (
          <li key={feature}>{feature}</li>
        ))}
      </ul>
    </div>
  );
};

export default Features;

import { NavLink } from 'react-router-dom';
import Container from '../Container/Container';
import Logo from '../Logo/Logo';
import styles from './Header.module.css';

const Header = () => {
  const classActive = ({ isActive }) => {
    return isActive ? styles.active : styles.link;
  };
  return (
    <header className={styles.header}>
      <Container>
        <nav className={styles.header_nav}>
          <Logo />
          <ul className={styles.header_nav_list}>
            <li>
              <NavLink to="/" exact="true" className={classActive}>
                Home
              </NavLink>
            </li>
            <li>
              <NavLink to="/catalog" className={classActive}>
                Catalog
              </NavLink>
            </li>
          </ul>
        </nav>
      </Container>
    </header>
  );
};

export default Header;

import CamperCard from '../CamperCard/CamperCard';
import styles from './CampersList.module.css';

const CampersList = ({ campers }) => {
  return (
    <div className={styles['campers-list']}>
      {campers.map(camper => (
        <CamperCard key={camper.id} camper={camper} />
      ))}
    </div>
  );
};

export default CampersList;

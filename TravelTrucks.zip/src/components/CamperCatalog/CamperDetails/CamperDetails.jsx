import ReviewsList from '../../ReviewsList/ReviewsList';
import Features from '../../Features/Features';

const CamperDetails = ({ camper }) => {
  const { name, features, reviews } = camper;

  return (
    <div>
      <h1>{name}</h1>
      <Features features={features} />
      <h2>Reviews</h2>
      <ReviewsList reviews={reviews} />
    </div>
  );
};

export default CamperDetails;

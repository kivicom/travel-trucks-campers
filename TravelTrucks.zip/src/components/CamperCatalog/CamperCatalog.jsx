import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCampers } from '../../redux/campers/campersOps';
import {
  selectFilteredCampers,
  selectIsLoading,
  selectError,
} from '../../redux/campers/campersSlice';

import FilterBar from './FilterBar/FilterBar';
import CampersList from './CampersList/CampersList';

import styles from './Catalog.module.css';

function CamperCatalog() {
  const dispatch = useDispatch();

  const campers = useSelector(selectFilteredCampers);
  const isLoading = useSelector(selectIsLoading);
  const error = useSelector(selectError);

  useEffect(() => {
    dispatch(fetchCampers());
  }, [dispatch]);

  if (isLoading) {
    return <p className={styles.loading}>Loading campers...</p>;
  }
  if (error) {
    return <p className={styles.error}>Error: {error}</p>;
  }

  return (
    <section className={styles.catalogSection}>
      <h1 className={styles.title}>Catalog</h1>

      <FilterBar />

      <CampersList campers={campers} />
    </section>
  );
}

export default CamperCatalog;

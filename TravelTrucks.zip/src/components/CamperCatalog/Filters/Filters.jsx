import styles from './Filters.module.css';

const Filters = () => {
  return (
    <div className={styles.filtersContainer}>
      <h2>Filters</h2>
      <div className={styles.filterGroup}>
        <label htmlFor="location">Location</label>
        <input type="text" id="location" placeholder="Enter location" />
      </div>
      <div className={styles.filterGroup}>
        <h3>Vehicle Equipment</h3>
        <div>
          <label>
            <input type="checkbox" name="AC" />
            AC
          </label>
          <label>
            <input type="checkbox" name="kitchen" />
            Kitchen
          </label>
        </div>
      </div>
      <button type="button" className={styles.searchButton}>
        Search
      </button>
    </div>
  );
};

export default Filters;

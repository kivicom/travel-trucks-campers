import { useDispatch, useSelector } from 'react-redux';
import {
  setLocation,
  setBodyType,
  toggleFeature,
  resetFilters,
  selectFilters,
} from '../../../redux/filters/filtersSlice';

const FilterBar = () => {
  const dispatch = useDispatch();
  const filters = useSelector(selectFilters);

  const handleLocationChange = e => {
    dispatch(setLocation(e.target.value));
  };

  const handleBodyTypeChange = e => {
    dispatch(setBodyType(e.target.value));
  };

  const handleFeatureToggle = feature => {
    dispatch(toggleFeature(feature));
  };

  return (
    <div>
      <input
        type="text"
        value={filters.location}
        onChange={handleLocationChange}
        placeholder="Search location"
      />
      <select value={filters.bodyType} onChange={handleBodyTypeChange}>
        <option value="">All body types</option>
        <option value="van">Van</option>
        <option value="trailer">Trailer</option>
      </select>
      <button onClick={() => handleFeatureToggle('AC')}>Toggle AC</button>
      <button onClick={() => dispatch(resetFilters())}>Reset Filters</button>
    </div>
  );
};

export default FilterBar;

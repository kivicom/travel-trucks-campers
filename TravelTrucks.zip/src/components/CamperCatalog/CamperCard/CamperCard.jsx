import { useNavigate } from 'react-router-dom';
import styles from './CamperCard.module.css';

const CamperCard = ({ camper }) => {
  const { id, name, location, price, gallery, ...features } = camper;
  const navigate = useNavigate();

  const image = gallery[0]?.thumb || 'default_image_url_here';

  const featureList = Object.entries(features)
    .filter(([, value]) => value === true)
    .map(([key]) => key);

  const handleShowMore = () => {
    navigate(`/catalog/${id}`);
  };

  return (
    <div className={styles.card}>
      <img src={image} alt={name} className={styles.image} />
      <div className={styles.info}>
        <h3 className={styles.name}>{name}</h3>
        <p className={styles.location}>{location}</p>
        <p className={styles.price}>€{price?.toLocaleString('en-US')},00</p>
        <div className={styles.features}>
          {featureList.map(feature => (
            <span key={feature} className={styles.feature}>
              {feature}
            </span>
          ))}
        </div>
        <button className={styles.showMore} onClick={handleShowMore}>
          Show more
        </button>
      </div>
    </div>
  );
};

export default CamperCard;

const ReviewsList = ({ reviews = [] }) => {
  // Перевіряємо, чи `reviews` — це масив, і чи не порожній
  if (!Array.isArray(reviews) || reviews.length === 0) {
    return <p>No reviews available.</p>;
  }

  return (
    <div>
      <h3>Reviews</h3>
      <ul>
        {reviews.map((review, index) => (
          <li key={index}>
            <p>
              <strong>{review.reviewer_name}</strong> - {review.reviewer_rating}
              ⭐
            </p>
            <p>{review.comment}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ReviewsList;

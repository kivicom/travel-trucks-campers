import { NavLink } from 'react-router-dom';
import sprite from '../../assets/icons/sprite.svg';
import styles from './Logo.module.css';

const Logo = () => {
  return (
    <>
      <NavLink to="/" className={styles.logo}>
        <svg className={styles.icon}>
          <use xlinkHref={`${sprite}#logo`} href={`${sprite}#logo`} />
        </svg>
      </NavLink>
    </>
  );
};

export default Logo;
